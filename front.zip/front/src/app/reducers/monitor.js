
import * as actionsTypes from '../../app/actions/actionsTypes';


const initialState = {
    newHost: ''
  };


export const clickReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'CLICK_UPDATE_VALUE':
        return {
          ...state,
          newHost: action.newValue
        };
      default:
        return state;
    }
  };
export function newHost(state = {}, action) {
    switch (action.type) {
        case actionsTypes.GET_MONITOR:
            return action.metric;
        case actionsTypes.GET_MONITORS:
            return action.metric;
    
        default:
            return state;
    }
}