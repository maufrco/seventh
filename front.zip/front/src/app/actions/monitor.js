import * as SeventhApi from '../../api/SeventhApi';
import * as actionsTypes from './actionsTypes';

export function getMonitors() {
    return dispatch => {
            SeventhApi.getMonitors()
            .then(metric => {
                    dispatch({ type: actionsTypes.GET_MONITORS, metric: metric.data })
                    return metric.data;
                }
            );
    }
}
export function getMonitor(newHost) {
    console.log("call getMonitor", newHost)
    return dispatch => {
            SeventhApi.getMonitor(newHost)
            .then(metric => {
                    dispatch({ type: actionsTypes.GET_MONITOR, metric: metric.data })
                    return metric.data;
                }
            );
    }
}
export function clickButton(host) {
    console.log("call clickButton", host)
    return dispatch => {
            SeventhApi.getMonitor(host)
            .then(value => {
                    dispatch({ type: actionsTypes.CLICK_UPDATE_VALUE, newHost: value.data })
                    return value.data;
                }
            );
    }
}