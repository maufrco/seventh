import styled from 'styled-components';

export const List = styled.ul`
    display: flex;
    justify-content: left;
    flex-wrap: wrap;
    padding: 0 3px;
    margin: 0;
    list-style: none;
    @media(max-width: 600px) {
        justify-content: center;
    }
`

export const Button = styled.button`
    cursor: pointer;
    background-color: transparent;
    border: none;
    padding: 3px;
    justify-content: center;
    margin:10px;
    text-align: center;
    color: #999999;
    text-transform: capitalize;
    font-size: 14px;
    transition: all 0.3s ease-out;

    :hover {
        font-weight: 600;
        color: #333333;
    }
`
