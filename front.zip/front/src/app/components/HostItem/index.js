import React, { Component } from 'react';
import { clickButton } from '../../actions/monitor';
import { connect } from 'react-redux';
import { Item, Button, Text } from './styles';
import DeleteForeverTwoToneIcon from '@material-ui/icons/DeleteForeverTwoTone';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';



class HostItem extends Component {
    constructor(props){
        super(props);
        this.clickButton = this.clickButton.bind(this);
    }
    clickButton(host){
        this.props.clickButton(host);
    }
    
    render() {
        const { host }  = this.props;
        return (
            
            <Item>
                <Text onClick={()=>this.clickButton(host)} >{host.name}</Text>
                <Button
                    type="button"
                    data-toggle="modal"
                    title="Editar host"
                    data-target="#metricModal"
                    onClick={()=>this.clickButton(host)}>
                    <EditTwoToneIcon fontSize="small"  />
                </Button>
                <Button
                    type="button"
                    title="Deletar host"
                    data-toggle="modal"
                    data-target="#metricModal"
                    onClick={()=>this.clickButton(host)}>
                    <DeleteForeverTwoToneIcon fontSize="small"  />
                </Button>
            </Item>
            
        )
    }
}

const mapDispatchToProps = dispatch => {
    return {
        clickButton: (list) => dispatch(clickButton(list))
    };
}

const HostItemContainer = connect(null, mapDispatchToProps)(HostItem);
export default HostItemContainer;