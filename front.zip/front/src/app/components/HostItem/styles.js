import styled from 'styled-components';

export const Item = styled.li`
    margin: 6px;
    border-radius: 6px;
    box-shadow: 0 0 1px 1px rgba(0, 0, 0, 0.07), 0 1px 1px 0 rgba(0, 0, 0, 0.16);
    background-color: #eeeeee;
    transition: all 0.5s ease-out;

    :hover {
        background-color: #e0e0e0;
        box-shadow: 0 0 2px 2px rgba(0,0,0,0.07), 0 2px 2px 0 rgba(0,0,0,0.16);
    }
`


export const Button = styled.button`
    cursor: pointer;
    background-color: transparent;
    border: none;
    padding: 3px;
    text-align: center;
    color: #999999;
    text-transform: capitalize;
    font-size: 14px;
    transition: all 0.3s ease-out;

    :hover {
        font-weight: 600;
        color: #333333;
    }
`
export const Text = styled.span`
    cursor: pointer;
    background-color: transparent;
    border: none;
    padding: 10px;
    color: #666;
    font-weight: 400;
    text-transform: capitalize;
    font-size: 16px;
    transition: all 0.3s ease-out;

`