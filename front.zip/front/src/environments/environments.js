export const NORRIS_URL = 'https://api.chucknorris.io/jokes/';
export const SERVER_URL = 'http://localhost:8080/';
export const HOSTS = 'categories';
export const METRIC = 'random?host=';
export const DEFAULT_TIMEOUT = 10000;