import * as SeventhApi from '../../api/SeventhApi';
import * as actionsTypes from './actionsTypes';

export function getHosts() {
    return dispatch => {
        SeventhApi.getHosts()
            .then(hosts => {
                    dispatch({ type: actionsTypes.GET_HOSTS, hosts: hosts.data })
                    return hosts.data;
                }
            );
    }
}
export function getHost() {
    return dispatch => {
        SeventhApi.getHost()
            .then(hosts => {
                    dispatch({ type: actionsTypes.GET_HOST, hosts: hosts.data })
                    return hosts.data;
                }
            );
    }
}

export function setHost(host) {
    return dispatch => {
        SeventhApi.getMonitor(host)
            .then(hosts => {
                    dispatch({ type: actionsTypes.SET_HOST, hosts: hosts.data })
                    return hosts.data;
                }
            );
    }
}

