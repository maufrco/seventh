export const GET_HOSTS = 'GET_HOSTS';
export const GET_HOST = 'GET_HOST';
export const POST_HOST = 'POST_HOST';
export const PUT_HOST = 'PUT_HOST';
export const SET_HOST = 'SET_HOST';
export const DELETE_HOST = 'DELETE_HOST';

export const GET_MONITOR = 'GET_MONITOR';
export const GET_MONITORS = 'GET_MONITORS';

export const CLICK_UPDATE_VALUE = 'CLICK_UPDATE_VALUE';