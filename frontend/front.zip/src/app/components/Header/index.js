import React, { Component } from 'react';
import { Container, Title } from './styles';

class Header extends Component {
    render() {
        return (
            <Container>
                <Title>Test Seventh - Mauricio de Oliveira Francisco</Title>
            </Container>
        )
    }
}

export default Header;