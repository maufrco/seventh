import React, { Component } from 'react';
import { getMonitor } from '../../actions/monitor';
import { connect } from 'react-redux';
import { Item, Button, Text } from './styles';
import DeleteForeverTwoToneIcon from '@material-ui/icons/DeleteForeverTwoTone';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';



class HostItem extends Component {
    constructor(props){
        super(props);
        this.getMonitor = this.getMonitor.bind(this);
    }
    getMonitor(host){
        this.props.getMonitor(host);
    }
    
    render() {
        const { host }  = this.props;
        return (
            
            <Item>
                <Text onClick={()=>this.getMonitor(host)} >{host.name}</Text>
                <Button
                    type="button"
                    data-toggle="modal"
                    title="Editar host"
                    data-target="#metricModal"
                    onClick={()=>this.getMonitor(host)}>
                    <EditTwoToneIcon fontSize="small"  />
                </Button>
                <Button
                    type="button"
                    title="Deletar host"
                    data-toggle="modal"
                    data-target="#metricModal"
                    onClick={()=>this.getMonitor(host)}>
                    <DeleteForeverTwoToneIcon fontSize="small"  />
                </Button>
            </Item>
            
        )
    }
}

const mapDispatchToProps = dispatch => {
    return {
        getMonitor: (list) => dispatch(getMonitor(list))
    };
}

const HostItemContainer = connect(null, mapDispatchToProps)(HostItem);
export default HostItemContainer;