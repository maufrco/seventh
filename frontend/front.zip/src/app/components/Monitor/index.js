import React, { Component } from 'react';
import { getMonitor } from '../../actions/monitor';
import { connect } from 'react-redux';
//import { containerChart} from './styles';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import HC_more from "highcharts/highcharts-more"; //module
HC_more(Highcharts); //init module


class Monitor extends Component {
    constructor(props){
        super(props);

        this.mapSeries = this.mapSeries.bind(this);

        this.allowChartUpdate = true;
        this.state = {};
        
    }
    componentDidMount() {
        console.log('componentDidMount')
        this.chart = this.refs.chartComponent.chart;
        //this.props.getMonitor({id:0})
    }
    
    mapSeries(chart) {
        console.log('mapSeries', chart, this.props)
      try {
        this.chartData = chart[0].results.map(result => [new Date(result["monitorDate"]).getTime(),result["timeResponse"]]);
         }
        catch(err) {
          //console.log(err);
        }
    }
    render() {
        console.log('render')
        const { newHost } = this.props;

        setInterval(() => {
            console.log(this.props)
          }, 10000);
          
        try {        
            console.log(this)
            this.chartData = newHost.results.map(result => [new Date(result["monitorDate"]).getTime(),result["timeResponse"]]);
            this.chartName = newHost.name;
        }
          catch(err) {
            console.log(err);
          }

       const options = {
            chart: {
              zoomType: 'x',
              spacingLeft: 30,
              spacingRight: 30,
              events: {
                load: function(e) {
                    console.log('load')
                    if (this.allowChartUpdate) {
                        this.allowChartUpdate = false;
                    }
                    
                    this.allowChartUpdate = true;
                    
                }
            }  
            },
            subtitle: {
              text: document.ontouchstart === undefined ?
                  'Clique e arraste na área de plotagem para ampliar':'Clique no grafico para amplias'
          },
          xAxis: {
            type: 'datetime'
        },
        yAxis: {
          title:{
            text: 'milisseconds'
          },          
      },
            credits: {
                enabled: false
            },
            title: {
              text: 'Host Monitorados'
            }, plotOptions: {
              area: {
                  fillColor: {
                      linearGradient: {
                          x1: 0,
                          y1: 0,
                          x2: 0,
                          y2: 1
                      },
                      stops: [
                          [0, Highcharts.getOptions().colors[0]],
                          [1, Highcharts.color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                      ]
                  },
                  marker: {
                      radius: 2
                  },
                  lineWidth: 1,
                  states: {
                      hover: {
                          lineWidth: 1
                      }
                  },
                  threshold: null
              }
          },

          series: [{
              type: 'area',
              name: this.chartName,
              data: this.chartData
          }]
      }

  //console.log({monitor})
        return (
            <HighchartsReact
            callback = {this.mapSeries}
            ref={"chartComponent"}
            allowChartUpdate={this.allowChartUpdate}
            highcharts={Highcharts}
            options={ options }
          />

        )
    }
}

  const mapStateToProps = function(store){ 
    return({
        newHost: store.newHost
    })
};
const mapDispatchToProps = dispatch => {
    return {
        getMonitor: (newHost) => dispatch(getMonitor(newHost))
    };
}

const MonitorContainer = connect(mapStateToProps, mapDispatchToProps)(Monitor);
export default MonitorContainer;